package com.example.factory;

public class SGBDFactory {

}
